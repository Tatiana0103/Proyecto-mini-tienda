import React from 'react'
import ProductList from './components/ProductList'
import CartDrawer from './components/CartDrawer'
import { useCart } from './contexts/CartContext'
import { useTheme } from './contexts/ThemeContext'

export default function App(){
  const [openCart, setOpenCart] = React.useState(false)
  const { totalItems } = useCart()
  const { theme, toggle } = useTheme()

  return (
    <div className="app">
      <header className="header">
        <div className="brand">Mini Tienda React</div>
        <div className="controls">
          <button className="button ghost" onClick={toggle}>{theme === 'light' ? '🌙 Dark' : '☀️ Light'}</button>
          <button className="button" onClick={() => setOpenCart(v => !v)}>Carrito ({totalItems})</button>
        </div>
      </header>
      <main>
        <ProductList />
      </main>
      {openCart && <CartDrawer onClose={() => setOpenCart(false)} />}
    </div>
  )
}
